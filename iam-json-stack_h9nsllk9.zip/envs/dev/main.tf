
locals {
  root_dir = abspath("${path.module}/../..")
}

module "stack" {
  source           = "${local.root_dir}/modules/policy_stack"
  apps             = var.apps
  policies_root    = "${local.root_dir}/policies/app"
  create_roles     = var.create_roles
  trust_principals = var.trust_principals
}
