
variable "region"         { type = string }
variable "backend_bucket" { type = string }
variable "lock_table"     { type = string }
variable "apps" {
  description = "Map of apps to target IAM role and optional tags"
  type = map(object({
    role_name = string
    tags      = optional(map(string), {})
  }))
}
variable "create_roles" { type = bool default = false }
variable "trust_principals" {
  description = "List of principal services or ARNs to trust if creating roles"
  type        = list(string)
  default     = ["ec2.amazonaws.com"]
}
