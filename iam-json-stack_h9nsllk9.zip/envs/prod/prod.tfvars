
region         = "us-east-1"
backend_bucket = "your-state-bucket"
lock_table     = "tf-state-locks"

apps = {
  app1 = { role_name = "app1-exec" }
}
