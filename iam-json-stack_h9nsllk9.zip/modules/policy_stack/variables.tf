
variable "apps" {
  description = "Map of apps to target IAM role and optional tags"
  type = map(object({
    role_name = string
    tags      = optional(map(string), {})
  }))
}
variable "policies_root"    { type = string }
variable "create_roles"     { type = bool   default = false }
variable "trust_principals" { type = list(string) default = ["ec2.amazonaws.com"] }
