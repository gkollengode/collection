
#!/usr/bin/env python3
import os, sys, json
q = json.load(sys.stdin)
d = q.get("dir")
files = []
if d and os.path.isdir(d):
    for name in sorted(os.listdir(d)):
        if name.endswith(".json"):
            files.append(os.path.join(d, name))
print(json.dumps(files))
