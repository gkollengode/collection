
locals {
  # build roles map (create or data source)
  roles = {
    for app, cfg in var.apps :
    app => (
      var.create_roles ? aws_iam_role.created[app] : data.aws_iam_role.existing[app]
    )
  }
}

# Discover JSON files per app using an external helper (portable)
data "external" "json_lists" {
  for_each = var.apps
  program  = ["python3", "${path.module}/tools/list_json.py"]
  query = {
    dir = "${var.policies_root}/${each.key}"
  }
}

# Read JSON and create customer-managed policies, then attach to role
locals {
  files = {
    for app, out in data.external.json_lists :
    app => (try(jsondecode(out.result), []))
  }

  policy_objs = {
    for app, filelist in local.files :
    app => [
      for f in filelist : aws_iam_policy.app[app][basename(f)]
    ]
  }
}

resource "aws_iam_policy" "app" {
  for_each = {
    for app, filelist in local.files :
    for f in filelist : "${app}:${f}" => { app = app, file = f }
  }
  name   = "${replace(each.value.app, "/", "-")}-${replace(basename(each.value.file), ".json", "")}"
  policy = file(each.value.file)
}

resource "aws_iam_role_policy_attachment" "attach" {
  for_each = {
    for app, filelist in local.files :
    for f in filelist : "${app}:${f}" => { app = app, file = f }
  }
  role       = local.roles[each.value.app].name
  policy_arn = aws_iam_policy.app[each.key].arn
}

# Role creation (optional)
resource "aws_iam_role" "created" {
  for_each = var.create_roles ? var.apps : {}
  name     = each.value.role_name
  assume_role_policy = jsonencode({
    Version = "2012-10-17",
    Statement = [{
      Effect = "Allow",
      Principal = {
        AWS    = [for p in var.trust_principals : p if can(regex("^arn:aws:iam::\d{12}:(role|user)/", p))],
        Service= [for p in var.trust_principals : p if endswith(p, ".amazonaws.com")]
      },
      Action = "sts:AssumeRole"
    }]
  })
  tags = try(each.value.tags, null)
}

# Adopt existing roles if not creating
data "aws_iam_role" "existing" {
  for_each = var.create_roles ? {} : var.apps
  name     = each.value.role_name
}
