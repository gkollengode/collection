
output "role_arns" {
  value = { for k, v in local.roles : k => v.arn }
}
output "attached_policies" {
  value = {
    for k, v in local.policy_objs :
    k => [for p in v : p.arn]
  }
}
