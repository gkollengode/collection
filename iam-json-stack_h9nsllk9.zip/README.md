
# IAM JSON Stack — drop-in JSON policies
Drop JSON policy files under `policies/app/<app_name>/`. The pipeline will auto-discover them and:
- create customer-managed policies (one per JSON file)
- attach them to the target role for that app
- run nightly via CI

## Quick start
1. Put your JSON policies into `policies/app/<app>/`.
2. Set `apps` map in `envs/dev/dev.tfvars` and/or `envs/prod/prod.tfvars` with role names.
3. `tofu init && tofu plan -var-file=envs/dev/dev.tfvars && tofu apply`

Roles: by default we **attach** to existing roles. Set `create_roles=true` to create them with your trust principals.
