# nfcu.middleware.playbooks

Playbook repo referencing WebSphere installation and operations collections.