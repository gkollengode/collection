# Security Policy Project — Post-build Sonar + Gemnasium + SBOM (CycloneDX)

This repo injects scans via Pipeline Execution Policies:
- SonarQube (post-build, with Buildah export)
- Gemnasium Dependency Scanning (official GitLab analyzer; runs in `test` by default, optional `.post`)
- SBOM (CycloneDX) via Syft in `.post` — from the rebuilt Docker image or filesystem

Point your policy to: `.policy/sonar/sonar-layer-post.yml`
