
# Terragrunt + OpenTofu EKS — root.hcl pattern

This repo uses **root.hcl** at the repository root (recommended shared config).  
Region-level `terragrunt.hcl` includes `root.hcl`, and each child stack includes the region file.

## Structure
- `root.hcl` — remote state, providers, globals
- `live/prod/us-east-1/terragrunt.hcl` — includes root, exposes shared `inputs`
- `live/prod/us-east-1/*/terragrunt.hcl` — include region, point to modules
- `modules/*` — Terraform modules (`eks-cluster`, `eks-nodegroups`, `eks-addons`, `monitoring`, `flux`)

## Run
```bash
cd live/prod/us-east-1
terragrunt run-all init -upgrade
terragrunt run-all plan
```

## Set these first
- In `root.hcl`: S3 bucket and DynamoDB lock table names
- In region `terragrunt.hcl`: subnet IDs, IAM role ARNs, Falcon CID, Splunk HEC token, etc.
