
# Child includes the region terragrunt.hcl (which already includes root.hcl)
include { path = find_in_parent_folders() }

terraform { source = "../../../..//modules/eks-cluster" }
# Inherits inputs: name, version, private_subnet_ids, cluster_role_arn
