
terraform {
  required_providers { aws = { source = "hashicorp/aws", version = ">= 5.0" } }
}

resource "aws_eks_cluster" "this" {
  name     = var.name
  version  = var.version
  role_arn = var.cluster_role_arn

  vpc_config { subnet_ids = var.private_subnet_ids }
}

output "cluster_name"        { value = aws_eks_cluster.this.name }
output "cluster_version"     { value = var.version }
output "private_subnet_ids"  { value = var.private_subnet_ids }
