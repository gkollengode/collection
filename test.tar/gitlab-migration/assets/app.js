const ROOT_GROUP_QUERY = `
query LabAdminRootGroup($rootPath: ID!, $groupSearch: String, $projectSearch: String) {
  group(fullPath: $rootPath) {
    id
    name
    fullPath
    description
    visibility
    projects(search: $projectSearch, includeSubgroups: false, first: 100) {
      nodes {
        id
        name
        fullPath
        description
        visibility
        archived
        lastActivityAt
        starCount
        repository {
          rootRef
        }
      }
    }
    descendantGroups(search: $groupSearch, includeParentDescendants: true, first: 100) {
      nodes {
        id
        name
        fullPath
        description
        visibility
        projects(search: $projectSearch, includeSubgroups: false, first: 100) {
          nodes {
            id
            name
            fullPath
            description
            visibility
            archived
            lastActivityAt
            starCount
            repository {
              rootRef
            }
          }
        }
      }
    }
  }
}`;

const TOP_LEVEL_GROUPS_QUERY = `
query LabAdminTopLevelGroups($groupSearch: String, $projectSearch: String) {
  groups(search: $groupSearch, topLevelOnly: true, allAvailable: true, first: 25) {
    nodes {
      id
      name
      fullPath
      description
      visibility
      projects(search: $projectSearch, includeSubgroups: false, first: 100) {
        nodes {
          id
          name
          fullPath
          description
          visibility
          archived
          lastActivityAt
          starCount
          repository {
            rootRef
          }
        }
      }
      descendantGroups(search: $groupSearch, includeParentDescendants: true, first: 100) {
        nodes {
          id
          name
          fullPath
          description
          visibility
          projects(search: $projectSearch, includeSubgroups: false, first: 100) {
            nodes {
              id
              name
              fullPath
              description
              visibility
              archived
              lastActivityAt
              starCount
              repository {
                rootRef
              }
            }
          }
        }
      }
    }
  }
}`;

const state = {
  groups: [],
  filteredGroups: [],
  selectedGroupId: null,
  selectedProjectIds: new Set(),
  lastError: ""
};

const els = {
  fileWarning: document.getElementById("file-warning"),
  gitlabUrl: document.getElementById("gitlab-url"),
  gitlabToken: document.getElementById("gitlab-token"),
  rootGroupPath: document.getElementById("root-group-path"),
  loadResources: document.getElementById("load-resources"),
  search: document.getElementById("resource-search"),
  visibility: document.getElementById("visibility-filter"),
  status: document.getElementById("status-filter"),
  resetFilters: document.getElementById("reset-filters"),
  groupList: document.getElementById("group-list"),
  browserCount: document.getElementById("browser-count"),
  selectedTitle: document.getElementById("selected-title"),
  selectedDescription: document.getElementById("selected-description"),
  selectedPath: document.getElementById("selected-path"),
  selectedProjectCount: document.getElementById("selected-project-count"),
  projectList: document.getElementById("project-list"),
  selectAllProjects: document.getElementById("select-all-projects"),
  clearProjects: document.getElementById("clear-projects"),
  graphqlStatus: document.getElementById("graphql-status"),
  inventoryLevel: document.getElementById("inventory-level"),
  inventoryVisibility: document.getElementById("inventory-visibility"),
  inventoryProjects: document.getElementById("inventory-projects"),
  inventorySelected: document.getElementById("inventory-selected"),
  inventoryArchived: document.getElementById("inventory-archived"),
  inventorySource: document.getElementById("inventory-source"),
  inventoryNote: document.getElementById("inventory-note")
};

if (window.location.protocol === "file:") {
  els.fileWarning.hidden = false;
}

function normalizeVisibility(value) {
  return String(value || "private").toLowerCase();
}

function depthFromPath(fullPath) {
  return String(fullPath || "").split("/").filter(Boolean).length - 1;
}

function normalizeProject(project) {
  return {
    ...project,
    visibility: normalizeVisibility(project.visibility),
    archived: Boolean(project.archived),
    repository: project.repository || { rootRef: "main" }
  };
}

function normalizeGroup(group) {
  return {
    ...group,
    depth: depthFromPath(group.fullPath),
    visibility: normalizeVisibility(group.visibility),
    projects: {
      nodes: (group.projects?.nodes || []).map(normalizeProject)
    }
  };
}

function uniqueGroups(groups) {
  const byPath = new Map();
  groups.filter(Boolean).forEach((group) => {
    byPath.set(group.fullPath, normalizeGroup(group));
  });

  return [...byPath.values()].sort((a, b) => a.fullPath.localeCompare(b.fullPath));
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatDate(value) {
  if (!value) return "No activity date";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "No activity date";
  return date.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric"
  });
}

async function postGraphql(query, variables) {
  const token = els.gitlabToken.value.trim();
  const gitlabUrl = els.gitlabUrl.value.trim().replace(/\/$/, "");

  if (!gitlabUrl || !token) {
    throw new Error("Enter a GitLab URL and access token before loading real GraphQL data.");
  }

  if (window.location.protocol === "file:") {
    throw new Error("Open the app with npm start at http://127.0.0.1:3000. GraphQL cannot run from file://.");
  }

  const response = await fetch("/api/gitlab/graphql", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      gitlabUrl,
      token,
      query,
      variables
    })
  });

  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(payload.errors?.[0]?.message || `GitLab GraphQL returned HTTP ${response.status}.`);
  }

  if (payload.errors?.length) {
    throw new Error(payload.errors.map((error) => error.message).join("; "));
  }

  return payload.data;
}

async function fetchGitLabResources() {
  const search = els.search.value.trim() || null;
  const projectSearch = search;
  const rootPath = els.rootGroupPath.value.trim();

  if (rootPath) {
    const data = await postGraphql(ROOT_GROUP_QUERY, {
      rootPath,
      groupSearch: search,
      projectSearch
    });

    if (!data.group) {
      throw new Error(`No group found at ${rootPath}.`);
    }

    return uniqueGroups([data.group, ...(data.group.descendantGroups?.nodes || [])]);
  }

  const data = await postGraphql(TOP_LEVEL_GROUPS_QUERY, {
    groupSearch: search,
    projectSearch
  });

  return uniqueGroups((data.groups?.nodes || []).flatMap((group) => [
    group,
    ...(group.descendantGroups?.nodes || [])
  ]));
}

function getSelectedGroup() {
  return state.groups.find((group) => group.id === state.selectedGroupId) || null;
}

function projectMatchesFilters(project, query, visibility, status) {
  const haystack = [
    project.name,
    project.fullPath,
    project.description,
    project.repository?.rootRef
  ].join(" ").toLowerCase();
  const matchesSearch = !query || haystack.includes(query);
  const matchesVisibility = visibility === "all" || project.visibility === visibility;
  const matchesStatus = status === "all"
    || (status === "archived" && project.archived)
    || (status === "active" && !project.archived);

  return matchesSearch && matchesVisibility && matchesStatus;
}

function groupMatchesFilters(group, query, visibility, status) {
  const groupHaystack = [
    group.name,
    group.fullPath,
    group.description
  ].join(" ").toLowerCase();
  const matchingProjects = group.projects.nodes.filter((project) => projectMatchesFilters(project, query, visibility, status));
  const groupSearchMatch = !query || groupHaystack.includes(query);
  const groupVisibilityMatch = visibility === "all" || group.visibility === visibility;
  const groupStatusMatch = status === "all" || matchingProjects.length > 0;

  return (groupSearchMatch && groupVisibilityMatch && groupStatusMatch) || matchingProjects.length > 0;
}

function applyFilters() {
  const query = els.search.value.trim().toLowerCase();
  const visibility = els.visibility.value;
  const status = els.status.value;

  state.filteredGroups = state.groups.filter((group) => groupMatchesFilters(group, query, visibility, status));

  if (state.selectedGroupId && !state.filteredGroups.some((group) => group.id === state.selectedGroupId)) {
    state.selectedGroupId = state.filteredGroups[0]?.id || null;
    state.selectedProjectIds.clear();
  }

  render();
}

function visibleProjectsForGroup(group) {
  if (!group) return [];

  const query = els.search.value.trim().toLowerCase();
  const visibility = els.visibility.value;
  const status = els.status.value;
  return group.projects.nodes.filter((project) => projectMatchesFilters(project, query, visibility, status));
}

function selectGroup(groupId) {
  state.selectedGroupId = groupId;
  const group = getSelectedGroup();
  state.selectedProjectIds = new Set((group?.projects.nodes || []).map((project) => project.id));
  render();
}

function toggleProject(projectId) {
  if (state.selectedProjectIds.has(projectId)) {
    state.selectedProjectIds.delete(projectId);
  } else {
    state.selectedProjectIds.add(projectId);
  }
  renderProjectList();
  renderSelectionSummary();
}

function renderGroupList() {
  els.browserCount.textContent = `${state.filteredGroups.length} group${state.filteredGroups.length === 1 ? "" : "s"} visible`;

  if (state.lastError) {
    els.groupList.innerHTML = `<div class="empty-state error-state">${escapeHtml(state.lastError)}</div>`;
    return;
  }

  if (!state.groups.length) {
    els.groupList.innerHTML = `<div class="empty-state">Connect to GitLab and load groups. No mock data is used.</div>`;
    return;
  }

  if (!state.filteredGroups.length) {
    els.groupList.innerHTML = `<div class="empty-state">No groups match the current filters.</div>`;
    return;
  }

  els.groupList.innerHTML = state.filteredGroups.map((group) => {
    const projects = group.projects.nodes;
    const archivedCount = projects.filter((project) => project.archived).length;
    const selected = group.id === state.selectedGroupId;
    const indent = Math.min(group.depth, 8) * 16;

    return `
      <button class="group-card" style="--depth-indent:${indent}px" type="button" data-group-id="${escapeHtml(group.id)}" aria-selected="${selected}">
        <div class="group-title">
          <div>
            <strong>${escapeHtml(group.name)}</strong>
            <span>${escapeHtml(group.fullPath)}</span>
          </div>
          <span class="tag ${escapeHtml(group.visibility)}">${escapeHtml(group.visibility)}</span>
        </div>
        <p class="meta-row">${escapeHtml(group.description || "No description")}</p>
        <div class="tag-row">
          <span class="tag">level ${group.depth + 1}</span>
          <span class="tag">${projects.length} direct projects</span>
          <span class="tag">${projects.filter((project) => !project.archived).length} active</span>
          ${archivedCount ? `<span class="tag archived">${archivedCount} archived</span>` : ""}
        </div>
      </button>
    `;
  }).join("");
}

function renderSelectionSummary() {
  const group = getSelectedGroup();
  if (!group) {
    els.selectedTitle.textContent = "Choose a group from the left panel";
    els.selectedDescription.textContent = "Load real GitLab groups, then choose a parent group or nested subgroup for export scope.";
    els.selectedPath.textContent = "No group selected";
    els.selectedProjectCount.textContent = "0 projects selected";
    els.inventoryLevel.textContent = "Not selected";
    els.inventoryVisibility.textContent = "Not selected";
    els.inventoryProjects.textContent = "0";
    els.inventorySelected.textContent = "0";
    els.inventoryArchived.textContent = "0";
    els.inventorySource.textContent = "Not connected";
    els.inventoryNote.textContent = "Load a real GitLab group to build a source inventory. Subgroups appear as their own selectable scopes in the left panel.";
    return;
  }

  const archivedCount = group.projects.nodes.filter((project) => project.archived).length;

  els.selectedTitle.textContent = group.name;
  els.selectedDescription.textContent = group.description || "No group description supplied by GitLab.";
  els.selectedPath.textContent = group.fullPath;
  els.selectedProjectCount.textContent = `${state.selectedProjectIds.size} of ${group.projects.nodes.length} direct projects selected`;
  els.inventoryLevel.textContent = `Level ${group.depth + 1}`;
  els.inventoryVisibility.textContent = group.visibility;
  els.inventoryProjects.textContent = group.projects.nodes.length;
  els.inventorySelected.textContent = state.selectedProjectIds.size;
  els.inventoryArchived.textContent = archivedCount;
  els.inventorySource.textContent = els.gitlabUrl.value.trim().replace(/\/$/, "") || "Not connected";
  els.inventoryNote.textContent = archivedCount
    ? "Archived projects are visible in scope and should be reviewed before export. Keep them selected only if the destination migration needs historical repositories."
    : "This selected scope has no archived direct projects. Continue with destination namespace mapping when ready.";
}

function renderProjectList() {
  const group = getSelectedGroup();
  const projects = visibleProjectsForGroup(group);

  if (!group) {
    els.projectList.innerHTML = `<div class="empty-state">Select a group to inspect projects.</div>`;
    return;
  }

  if (!projects.length) {
    els.projectList.innerHTML = `<div class="empty-state">No direct projects in ${escapeHtml(group.fullPath)} match the current filters.</div>`;
    return;
  }

  els.projectList.innerHTML = projects.map((project) => {
    const selected = state.selectedProjectIds.has(project.id);
    return `
      <button class="project-card ${selected ? "selected" : ""}" type="button" data-project-id="${escapeHtml(project.id)}" aria-pressed="${selected}">
        <div class="project-title">
          <div>
            <strong>${escapeHtml(project.name)}</strong>
            <span>${escapeHtml(project.fullPath)}</span>
          </div>
          <span class="tag ${project.archived ? "archived" : escapeHtml(project.visibility)}">${project.archived ? "archived" : escapeHtml(project.visibility)}</span>
        </div>
        <p class="meta-row">${escapeHtml(project.description || "No description")}</p>
        <div class="tag-row">
          <span class="tag">root: ${escapeHtml(project.repository?.rootRef || "main")}</span>
          <span class="tag">${project.starCount ?? 0} stars</span>
          <span class="tag">last active ${formatDate(project.lastActivityAt)}</span>
        </div>
      </button>
    `;
  }).join("");
}

function render() {
  renderGroupList();
  renderSelectionSummary();
  renderProjectList();
}

async function loadResources() {
  els.loadResources.disabled = true;
  els.loadResources.textContent = "Loading real GraphQL...";
  els.graphqlStatus.textContent = "Querying GitLab GraphQL...";
  state.lastError = "";

  try {
    state.groups = await fetchGitLabResources();
    state.filteredGroups = [...state.groups];
    state.selectedGroupId = state.groups[0]?.id || null;
    state.selectedProjectIds = new Set((getSelectedGroup()?.projects.nodes || []).map((project) => project.id));
    els.graphqlStatus.textContent = `GraphQL live: ${state.groups.length} groups`;
    applyFilters();
  } catch (error) {
    console.error(error);
    state.groups = [];
    state.filteredGroups = [];
    state.selectedGroupId = null;
    state.selectedProjectIds.clear();
    state.lastError = error.message || "Unable to load GitLab groups.";
    els.graphqlStatus.textContent = "GraphQL connection required";
    render();
  } finally {
    els.loadResources.disabled = false;
    els.loadResources.textContent = "Load groups and projects";
  }
}

els.loadResources.addEventListener("click", loadResources);
els.search.addEventListener("input", () => {
  applyFilters();
});
els.visibility.addEventListener("change", applyFilters);
els.status.addEventListener("change", applyFilters);
els.resetFilters.addEventListener("click", () => {
  els.search.value = "";
  els.visibility.value = "all";
  els.status.value = "all";
  applyFilters();
});

els.groupList.addEventListener("click", (event) => {
  const groupButton = event.target.closest("[data-group-id]");
  if (!groupButton) return;
  selectGroup(groupButton.dataset.groupId);
});

els.projectList.addEventListener("click", (event) => {
  const projectButton = event.target.closest("[data-project-id]");
  if (!projectButton) return;
  toggleProject(projectButton.dataset.projectId);
});

els.selectAllProjects.addEventListener("click", () => {
  const group = getSelectedGroup();
  visibleProjectsForGroup(group).forEach((project) => state.selectedProjectIds.add(project.id));
  renderProjectList();
  renderSelectionSummary();
});

els.clearProjects.addEventListener("click", () => {
  state.selectedProjectIds.clear();
  renderProjectList();
  renderSelectionSummary();
});

render();
