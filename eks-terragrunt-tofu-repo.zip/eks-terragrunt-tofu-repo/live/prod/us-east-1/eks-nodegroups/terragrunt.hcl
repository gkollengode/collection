include { path = find_in_parent_folders() }
    terraform { source = "../../../..//modules/eks-nodegroups" }

    dependency "cluster" {
      config_path = "../eks-cluster"
      mock_outputs = { cluster_name = "placeholder", private_subnet_ids = ["subnet-x","subnet-y"] }
      mock_outputs_allowed_terraform_commands = ["plan"]
    }

    inputs = {
      cluster_name       = dependency.cluster.outputs.cluster_name
      private_subnet_ids = var.private_subnet_ids
      node_role_arn      = var.node_role_arn
      node_groups = {
        blue = { min_size=1, max_size=3, desired_size=2, instance_types=["t3.large"], capacity_type="ON_DEMAND", labels={role="general"}, taints=[] }
        green = { min_size=0, max_size=5, desired_size=0, instance_types=["t3.large"], capacity_type="SPOT", labels={role="batch"}, taints=[{key="batch", value="true", effect="NO_SCHEDULE"}] }
      }
    }
