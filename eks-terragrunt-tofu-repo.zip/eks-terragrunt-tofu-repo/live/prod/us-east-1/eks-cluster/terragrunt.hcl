
include { path = find_in_parent_folders() }

terraform { source = "../../../..//modules/eks-cluster" }

inputs = {
  name               = "t3c-prod"
  version            = "1.30"
  private_subnet_ids = ["subnet-aaa", "subnet-bbb", "subnet-ccc"]
  cluster_role_arn   = "arn:aws:iam::123456789012:role/eks-cluster-role"
}
