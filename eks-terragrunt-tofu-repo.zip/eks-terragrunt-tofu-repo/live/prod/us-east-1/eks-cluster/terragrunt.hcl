include { path = find_in_parent_folders() }
    terraform { source = "../../../..//modules/eks-cluster" }
    # Inherits: name, version, private_subnet_ids, cluster_role_arn
