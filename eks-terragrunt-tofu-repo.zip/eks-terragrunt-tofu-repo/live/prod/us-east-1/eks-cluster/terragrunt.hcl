
include { path = find_in_parent_folders() }

terraform { source = "../../../..//modules/eks-cluster" }

locals {
  cluster_name = try(local.cluster_name, "t3c-prod")
  eks_version  = try(local.eks_version, "1.30")
  private_subnet_ids = try(local.private_subnet_ids, ["subnet-aaa","subnet-bbb","subnet-ccc"])
  cluster_role_arn   = try(local.eks_cluster_role_arn, "arn:aws:iam::123456789012:role/eks-cluster-role")
}

inputs = {
  name               = local.cluster_name
  version            = local.eks_version
  private_subnet_ids = local.private_subnet_ids
  cluster_role_arn   = local.cluster_role_arn
}
