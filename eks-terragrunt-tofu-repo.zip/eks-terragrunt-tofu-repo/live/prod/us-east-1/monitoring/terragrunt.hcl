
include { path = find_in_parent_folders() }

terraform { source = "../../../..//modules/monitoring" }

dependency "cluster" {
  config_path = "../eks-cluster"
  mock_outputs = { cluster_name = "placeholder", region = "us-east-1" }
  mock_outputs_allowed_terraform_commands = ["plan"]
}

locals {
  region    = try(local.region, "us-east-1")
  namespace = "monitoring"
}

inputs = {
  cluster_name = dependency.cluster.outputs.cluster_name
  region       = local.region
  namespace    = local.namespace

  falcon_cid           = "CHANGE_ME_FALCON_CID"
  falcon_cloud         = "us-1"
  falcon_client_id     = null
  falcon_client_secret = null

  splunk_hec_url   = "https://splunk.example.com:8088"
  splunk_hec_token = "CHANGE_ME_SPLUNK_HEC_TOKEN"
  splunk_index     = "k8s"
}
