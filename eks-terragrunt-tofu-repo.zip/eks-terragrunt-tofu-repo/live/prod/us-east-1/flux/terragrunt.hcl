
include { path = find_in_parent_folders() }

terraform { source = "../../../..//modules/flux" }

dependency "cluster" {
  config_path = "../eks-cluster"
  mock_outputs = { cluster_name = "placeholder" }
  mock_outputs_allowed_terraform_commands = ["plan"]
}

inputs = {
  cluster_name = dependency.cluster.outputs.cluster_name
  namespace    = "flux-system"
  ssh_private_key = null
  ssh_known_hosts = ""

  apps = {
    platform = {
      url   = "https://github.com/your-org/platform-manifests.git"
      ref   = "main"
      path  = "./clusters/prod/us-east-1/platform"
      interval = "1m"
      prune    = true
      create_namespace = true
      target_namespace = "platform"
    }
    payments = {
      url   = "ssh://git@github.com/your-org/payments.git"
      ref   = "main"
      path  = "./deploy/kustomize/overlays/prod"
      interval = "1m"
      prune    = true
      create_namespace = true
      target_namespace = "payments"
    }
  }
}
