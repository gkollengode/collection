
include { path = find_in_parent_folders() }

terraform { source = "../../../..//modules/eks-addons" }

dependency "cluster" {
  config_path = "../eks-cluster"
  mock_outputs = { cluster_name = "placeholder", cluster_version = "1.30" }
  mock_outputs_allowed_terraform_commands = ["plan"]
}

locals {
  ebs_csi_role = try(local.ebs_csi_irsa_role_arn, null)
  addons = {
    vpc-cni = {
      addon_name        = "vpc-cni"
      version           = "v1.18.2-eksbuild.1"
      resolve_conflicts = "OVERWRITE"
    }
    coredns = {
      addon_name        = "coredns"
      version           = "v1.11.1-eksbuild.1"
      resolve_conflicts = "OVERWRITE"
    }
    kube-proxy = {
      addon_name        = "kube-proxy"
      version           = "v1.30.0-eksbuild.1"
      resolve_conflicts = "OVERWRITE"
    }
    aws-ebs-csi-driver = {
      addon_name               = "aws-ebs-csi-driver"
      version                  = "v1.30.0-eksbuild.1"
      resolve_conflicts        = "OVERWRITE"
      service_account_role_arn = local.ebs_csi_role
    }
  }
}

inputs = {
  cluster_name    = dependency.cluster.outputs.cluster_name
  cluster_version = dependency.cluster.outputs.cluster_version
  addons          = local.addons
}
