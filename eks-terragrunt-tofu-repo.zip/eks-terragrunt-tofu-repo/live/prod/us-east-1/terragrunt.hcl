
###############################################################
# live/prod/us-east-1/terragrunt.hcl
# Region-level config and shared inputs for all stacks below
###############################################################

include {
  path = find_in_parent_folders()
}

locals {
  env         = "prod"
  region      = "us-east-1"
  project     = "t3c"

  vpc_id = "vpc-0abc123456789def"
  private_subnet_ids = [
    "subnet-0123456789abcdef0",
    "subnet-0fedcba9876543210",
    "subnet-0a1b2c3d4e5f6a7b8"
  ]

  eks_cluster_role_arn    = "arn:aws:iam::123456789012:role/eks-prod-cluster-role"
  eks_nodegroup_role_arn  = "arn:aws:iam::123456789012:role/eks-prod-nodegroup-role"
  ebs_csi_irsa_role_arn   = "arn:aws:iam::123456789012:role/AmazonEKS_EBS_CSI_DriverRole"

  cluster_name = "t3c-prod"
  eks_version  = "1.30"
}

inputs = {
  env                = local.env
  region             = local.region
  project            = local.project
  vpc_id             = local.vpc_id
  private_subnet_ids = local.private_subnet_ids
  eks_cluster_role_arn   = local.eks_cluster_role_arn
  eks_nodegroup_role_arn = local.eks_nodegroup_role_arn
  ebs_csi_irsa_role_arn  = local.ebs_csi_irsa_role_arn
  cluster_name       = local.cluster_name
  eks_version        = local.eks_version
}
