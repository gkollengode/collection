include { path = find_in_parent_folders() }

inputs = {
  name               = "t3c-prod"
  version            = "1.30"
  private_subnet_ids = [
    "subnet-0123456789abcdef0",
    "subnet-0fedcba9876543210",
    "subnet-0a1b2c3d4e5f6a7b8"
  ]
  cluster_role_arn   = "arn:aws:iam::123456789012:role/eks-prod-cluster-role"
  node_role_arn      = "arn:aws:iam::123456789012:role/eks-prod-nodegroup-role"
  ebs_csi_irsa_role_arn = "arn:aws:iam::123456789012:role/AmazonEKS_EBS_CSI_DriverRole"
}
