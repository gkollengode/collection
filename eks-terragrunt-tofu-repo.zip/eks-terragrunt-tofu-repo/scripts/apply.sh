
#!/usr/bin/env bash
set -euo pipefail
export TERRAGRUNT_TFPATH="${TERRAGRUNT_TFPATH:-tofu}"
REGION_DIR="${1:-live/prod/us-east-1}"
cd "$REGION_DIR"
terragrunt run-all apply --terragrunt-non-interactive --terragrunt-include-external-dependencies
