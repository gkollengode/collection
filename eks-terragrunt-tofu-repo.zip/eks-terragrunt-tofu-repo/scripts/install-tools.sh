
#!/usr/bin/env bash
set -euo pipefail
apk add --no-cache bash curl unzip git jq openssh
TOFU_VERSION="${TOFU_VERSION:-1.7.2}"
TG_VERSION="${TG_VERSION:-0.67.6}"
curl -L -o /tmp/tofu.zip "https://github.com/opentofu/opentofu/releases/download/v${TOFU_VERSION}/tofu_${TOFU_VERSION}_linux_amd64.zip"
unzip /tmp/tofu.zip -d /usr/local/bin
chmod +x /usr/local/bin/tofu
curl -L -o /usr/local/bin/terragrunt "https://github.com/gruntwork-io/terragrunt/releases/download/v${TG_VERSION}/terragrunt_linux_amd64"
chmod +x /usr/local/bin/terragrunt
terragrunt --version
tofu version
