
#!/usr/bin/env bash
set -euo pipefail
export TERRAGRUNT_TFPATH="${TERRAGRUNT_TFPATH:-tofu}"
REGION_DIR="${1:-live/prod/us-east-1}"
cd "$REGION_DIR"
terragrunt run-all init -upgrade --terragrunt-non-interactive
terragrunt run-all plan --terragrunt-non-interactive
