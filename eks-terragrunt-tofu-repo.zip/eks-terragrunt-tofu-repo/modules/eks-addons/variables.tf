variable "cluster_name"    { type = string }
    variable "cluster_version" { type = string }
    variable "addons" {
      type = map(object({
        addon_name               = string
        version                  = string
        resolve_conflicts        = optional(string, "OVERWRITE")
        service_account_role_arn = optional(string, null)
        configuration_values     = optional(string, null)
      }))
    }
