
terraform {
  required_providers {
    aws = { source = "hashicorp/aws", version = ">= 5.0" }
  }
}

resource "aws_eks_addon" "this" {
  for_each = var.addons

  cluster_name             = var.cluster_name
  addon_name               = each.value.addon_name
  addon_version            = each.value.version
  resolve_conflicts        = try(each.value.resolve_conflicts, "OVERWRITE")
  service_account_role_arn = try(each.value.service_account_role_arn, null)
  configuration_values     = try(each.value.configuration_values, null)

  tags = {
    ManagedBy   = "Terragrunt"
  }
}

output "addon_names" {
  value = [for k, v in aws_eks_addon.this : v.addon_name]
}
