
terraform {
  required_providers {
    aws = { source = "hashicorp/aws", version = ">= 5.0" }
    helm = { source = "hashicorp/helm", version = ">= 2.11.0" }
    kubernetes = { source = "hashicorp/kubernetes", version = ">= 2.26.0" }
    kubectl = { source = "gavinbunney/kubectl", version = ">= 1.14.0" }
  }
}

data "aws_eks_cluster" "this" { name = var.cluster_name }
data "aws_eks_cluster_auth" "this" { name = var.cluster_name }

provider "kubernetes" {
  host                   = data.aws_eks_cluster.this.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.this.certificate_authority[0].data)
  token                  = data.aws_eks_cluster_auth.this.token
}

provider "helm" {
  kubernetes {
    host                   = data.aws_eks_cluster.this.endpoint
    cluster_ca_certificate = base64decode(data.aws_eks_cluster.this.certificate_authority[0].data)
    token                  = data.aws_eks_cluster_auth.this.token
  }
}

provider "kubectl" {
  host                   = data.aws_eks_cluster.this.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.this.certificate_authority[0].data)
  token                  = data.aws_eks_cluster_auth.this.token
  load_config_file       = false
}

resource "kubernetes_namespace" "flux" {
  metadata { name = var.namespace }
}

resource "kubernetes_secret" "flux_git_ssh" {
  count = var.ssh_private_key == null ? 0 : 1
  metadata {
    name      = "flux-git-ssh"
    namespace = var.namespace
  }
  type = "kubernetes.io/ssh-auth"
  data = {
    "ssh-privatekey" = base64encode(var.ssh_private_key)
    "known_hosts"    = base64encode(var.ssh_known_hosts)
  }
}

resource "helm_release" "flux" {
  name             = "flux2"
  repository       = "https://fluxcd-community.github.io/helm-charts"
  chart            = "flux2"
  namespace        = var.namespace
  create_namespace = false

  values = [<<-YAML
    installCRDs: true
  YAML
  ]
}

locals { apps = var.apps }

resource "kubectl_manifest" "gitrepositories" {
  for_each = local.apps
  yaml_body = yamlencode({
    apiVersion = "source.toolkit.fluxcd.io/v1"
    kind       = "GitRepository"
    metadata = {
      name      = each.key
      namespace = var.namespace
    }
    spec = {
      interval = try(each.value.interval, "1m")
      url      = each.value.url
      ref      = { branch = try(each.value.ref, "main") }
      secretRef = var.ssh_private_key == null ? null : { name = kubernetes_secret.flux_git_ssh[0].metadata[0].name }
    }
  })
  depends_on = [helm_release.flux]
}

resource "kubernetes_namespace" "app_ns" {
  for_each = {
    for k, v in local.apps : k => v
    if try(v.create_namespace, true) && try(v.target_namespace, null) != null
  }
  metadata { name = each.value.target_namespace }
}

resource "kubectl_manifest" "kustomizations" {
  for_each = local.apps
  yaml_body = yamlencode({
    apiVersion = "kustomize.toolkit.fluxcd.io/v1"
    kind       = "Kustomization"
    metadata = {
      name      = each.key
      namespace = var.namespace
    }
    spec = {
      interval  = try(each.value.interval, "1m")
      prune     = try(each.value.prune, true)
      suspend   = try(each.value.suspend, false)
      sourceRef = { kind = "GitRepository", name = each.key }
      path      = each.value.path
      targetNamespace = try(each.value.target_namespace, null)
    }
  })
  depends_on = [helm_release.flux, kubectl_manifest.gitrepositories]
}
