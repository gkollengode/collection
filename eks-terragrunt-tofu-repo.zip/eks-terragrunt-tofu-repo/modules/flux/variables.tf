variable "cluster_name" { type = string }
    variable "namespace"    { type = string, default = "flux-system" }
    variable "apps" {
      type = map(object({
        url = string
        ref = optional(string, "main")
        path = string
        interval = optional(string, "1m")
        prune = optional(bool, true)
        suspend = optional(bool, false)
        create_namespace = optional(bool, true)
        target_namespace = optional(string, null)
      }))
      default = {}
    }
    variable "ssh_known_hosts" { type = string, default = "" }
    variable "ssh_private_key" { type = string, default = null }
