
terraform {
  required_providers {
    aws = { source = "hashicorp/aws", version = ">= 5.0" }
    helm = { source = "hashicorp/helm", version = ">= 2.11.0" }
    kubernetes = { source = "hashicorp/kubernetes", version = ">= 2.26.0" }
  }
}

data "aws_eks_cluster" "this" { name = var.cluster_name }
data "aws_eks_cluster_auth" "this" { name = var.cluster_name }

provider "kubernetes" {
  host                   = data.aws_eks_cluster.this.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.this.certificate_authority[0].data)
  token                  = data.aws_eks_cluster_auth.this.token
}

provider "helm" {
  kubernetes {
    host                   = data.aws_eks_cluster.this.endpoint
    cluster_ca_certificate = base64decode(data.aws_eks_cluster.this.certificate_authority[0].data)
    token                  = data.aws_eks_cluster_auth.this.token
  }
}

resource "kubernetes_namespace" "monitoring" {
  metadata { name = var.namespace }
}

resource "kubernetes_secret" "splunk" {
  metadata {
    name      = "splunk-hec"
    namespace = var.namespace
  }
  data = {
    hec_token = var.splunk_hec_token
  }
  type = "Opaque"
}

locals {
  tolerations_yaml = yamlencode(var.extra_tolerations)
}

resource "helm_release" "crowdstrike" {
  name       = "falcon-sensor"
  repository = "https://crowdstrike.github.io/falcon-helm"
  chart      = "falcon-sensor"
  namespace  = var.namespace
  create_namespace = false

  set { name = "falcon.cid", value = var.falcon_cid }
  set { name = "falcon.cloudRegion", value = var.falcon_cloud }

  dynamic "set" {
    for_each = var.falcon_client_id == null ? [] : [1]
    content { name = "falcon.clientID", value = var.falcon_client_id }
  }
  dynamic "set" {
    for_each = var.falcon_client_secret == null ? [] : [1]
    content { name = "falcon.clientSecret", value = var.falcon_client_secret }
  }

  values = [<<-YAML
    daemonset:
      tolerations: ${local.tolerations_yaml}
  YAML
  ]
}

resource "helm_release" "fluent_bit" {
  name       = "fluent-bit"
  repository = "https://fluent.github.io/helm-charts"
  chart      = "fluent-bit"
  namespace  = var.namespace
  create_namespace = false

  values = [<<-YAML
    tolerations: ${local.tolerations_yaml}
    config:
      service: |
        [SERVICE]
            Flush        1
            Grace        30
            Daemon       Off
            Log_Level    info
      inputs: |
        [INPUT]
            Name              tail
            Path              /var/log/containers/*.log
            Tag               kube.*
            Parser            docker
            Mem_Buf_Limit     50MB
            Skip_Long_Lines   On
        [INPUT]
            Name              systemd
            Tag               host.*
            Systemd_Filter    _SYSTEMD_UNIT=kubelet.service
            Read_From_Tail    On
      outputs: |
        [OUTPUT]
            Name            http
            Match           *
            Host            ${replace(var.splunk_hec_url, "https://", "")}
            Port            8088
            TLS             On
            URI             /services/collector
            Header          Authorization Bearer ${base64decode(kubernetes_secret.splunk.data.hec_token)}
            Format          json
            Retry_Limit     5
      filters: |
        [FILTER]
            Name                kubernetes
            Match               kube.*
            Kube_URL            https://kubernetes.default.svc:443
            Kube_Tag_Prefix     kube.var.log.containers.
            Merge_Log           On
            K8S-Logging.Parser  On
            K8S-Logging.Exclude On
  YAML
  ]
}
