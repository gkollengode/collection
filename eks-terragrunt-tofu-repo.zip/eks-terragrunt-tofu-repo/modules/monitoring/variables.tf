variable "cluster_name" { type = string }
    variable "region"       { type = string }
    variable "namespace"    { type = string, default = "monitoring" }
    variable "falcon_cid"   { type = string }
    variable "falcon_cloud" { type = string }
    variable "falcon_client_id"     { type = string, default = null }
    variable "falcon_client_secret" { type = string, default = null }
    variable "splunk_hec_url"   { type = string }
    variable "splunk_hec_token" { type = string }
    variable "splunk_index"     { type = string, default = "k8s" }
    variable "extra_tolerations" {
      type = list(object({ key=string, operator=string, value=string, effect=string }))
      default = [
        { key="node-role.kubernetes.io/control-plane", operator="Exists", value="", effect="NoSchedule" },
        { key="CriticalAddonsOnly", operator="Exists", value="", effect="NoSchedule" }
      ]
    }
