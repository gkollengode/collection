variable "name"               { type = string }
    variable "version"            { type = string }
    variable "private_subnet_ids" { type = list(string) }
    variable "cluster_role_arn"   { type = string }
