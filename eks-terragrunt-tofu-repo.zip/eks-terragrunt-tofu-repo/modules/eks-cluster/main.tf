
terraform {
  required_providers {
    aws = { source = "hashicorp/aws", version = ">= 5.0" }
  }
}

resource "aws_eks_cluster" "this" {
  name     = var.name
  version  = var.version
  role_arn = var.cluster_role_arn

  vpc_config {
    subnet_ids = var.private_subnet_ids
  }
}

output "cluster_name" {
  value = aws_eks_cluster.this.name
}
output "cluster_sg_id" {
  value = aws_eks_cluster.this.vpc_config[0].cluster_security_group_id
}
output "private_subnet_ids" {
  value = var.private_subnet_ids
}
