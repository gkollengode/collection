terraform { required_providers { aws = { source = "hashicorp/aws", version = ">= 5.0" } } }
    resource "aws_eks_node_group" "this" {
      for_each        = var.node_groups
      cluster_name    = var.cluster_name
      node_group_name = each.key
      node_role_arn   = var.node_role_arn
      subnet_ids      = var.private_subnet_ids
      instance_types  = each.value.instance_types
      capacity_type   = each.value.capacity_type
      scaling_config { min_size = each.value.min_size, max_size = each.value.max_size, desired_size = each.value.desired_size }
      dynamic "taint" {
        for_each = each.value.taints
        content { key = taint.value.key, value = taint.value.value, effect = taint.value.effect }
      }
      update_config { max_unavailable = 1 }
      lifecycle { ignore_changes = [scaling_config[0].desired_size] }
    }
