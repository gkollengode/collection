variable "cluster_name"       { type = string }
    variable "private_subnet_ids" { type = list(string) }
    variable "node_role_arn"      { type = string }
    variable "node_groups" {
      type = map(object({
        min_size       = number
        max_size       = number
        desired_size   = number
        instance_types = list(string)
        capacity_type  = optional(string, "ON_DEMAND")
        labels         = optional(map(string), {})
        taints         = optional(list(object({ key=string, value=string, effect=string })), [])
      }))
    }
