
# EKS with Terragrunt and OpenTofu

This repo provisions:
- EKS control plane
- EKS managed node groups with for_each map
- AWS-managed EKS add-ons (vpc-cni, coredns, kube-proxy, aws-ebs-csi)
- Monitoring stack with CrowdStrike Falcon Sensor and Fluent Bit to Splunk
- Flux controllers with modular app repos
- GitLab pipeline to validate, plan, and manually apply

## Prereqs
- AWS credentials for EKS, IAM, S3, DynamoDB, EC2
- S3 bucket and DynamoDB lock table for remote state (edit root `terragrunt.hcl`)
- kubectl access to EKS once created

## Apply order
From the region folder:
```
terragrunt run-all apply
```
Terragrunt resolves dependencies so the order is: eks-cluster → eks-addons → monitoring → flux → eks-nodegroups.

## Add a node group
Edit `live/prod/us-east-1/eks-nodegroups/terragrunt.hcl` and add a new key under `inputs.node_groups`.

## Add an app repo to Flux
Edit `live/prod/us-east-1/flux/terragrunt.hcl` under `inputs.apps` and add another entry.

## GitLab CI
Set CI variables: AWS creds or role, AWS_REGION, and optionally TOFU_VERSION and TG_VERSION.
Pipeline stages: validate, plan, manual apply.

## Secrets
Replace placeholders:
- `CHANGE_ME_tfstate_bucket`, `CHANGE_ME_tf_lock_table`
- `CHANGE_ME_FALCON_CID`, `CHANGE_ME_SPLUNK_HEC_TOKEN`
- IAM role ARNs and subnet IDs in region-level `live/prod/us-east-1/terragrunt.hcl`

## Notes
- DaemonSets do not run on Fargate. Route Fargate logs separately if used.
- Consider migrating monitoring Helm releases into Flux for full GitOps later.
