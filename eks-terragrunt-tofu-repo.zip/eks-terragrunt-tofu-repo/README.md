
# EKS with Terragrunt and OpenTofu
This repo provisions:
- EKS control plane
- EKS managed node groups with for_each map
- Monitoring stack with CrowdStrike Falcon Sensor and Fluent Bit to Splunk
- Flux controllers with modular app repos

## Prereqs
- AWS credentials with permissions for EKS, IAM, S3, DynamoDB, EC2
- S3 bucket and DynamoDB lock table for state (edit `terragrunt.hcl` at root)
- kubectl access to EKS once created

## Order
From region directory:
```
terragrunt run-all apply
```
This applies cluster, monitoring, flux, then nodegroups.

## Add a node group
Edit `live/prod/us-east-1/eks-nodegroups/terragrunt.hcl` and add a new key under `inputs.node_groups`. Apply the nodegroups stack. DaemonSets will land automatically on new nodes.

## Add an app repo to Flux
Edit `live/prod/us-east-1/flux/terragrunt.hcl` inputs `apps` map and add another entry. Apply the flux stack.

## GitLab CI
The pipeline has validate, plan, and manual apply stages. It installs OpenTofu and Terragrunt in an Alpine image. Set these CI variables:
- AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY or use a role
- AWS_REGION
- TOFU_VERSION and TG_VERSION if you need to pin
- TG_REGION_DIR if your live path differs

## Secrets
Replace placeholders:
- `CHANGE_ME_tfstate_bucket`, `CHANGE_ME_tf_lock_table`
- `CHANGE_ME_FALCON_CID`, `CHANGE_ME_SPLUNK_HEC_TOKEN`
- IAM role ARNs, subnet IDs

## Notes
- DaemonSets do not run on Fargate. Route Fargate logs separately if used.
- Consider moving monitoring Helm releases under Flux later for full GitOps.
