locals {
  aws_region   = "us-east-1"
  env          = "prod"
  project      = "t3c"
  state_bucket = "CHANGE_ME_tfstate_bucket"
  lock_table   = "CHANGE_ME_tf_lock_table"
}

remote_state {
  backend = "s3"
  config = {
    bucket         = local.state_bucket
    key            = "${path_relative_to_include()}/terraform.tfstate"
    region         = local.aws_region
    dynamodb_table = local.lock_table
    encrypt        = true
  }
}

generate "provider" {
  path      = "provider.tf"
  if_exists = "overwrite"
  contents  = <<-EOF
    terraform {
      required_version = ">= 1.6.0"
      required_providers {
        aws = { source = "hashicorp/aws", version = ">= 5.0" }
        kubernetes = { source = "hashicorp/kubernetes", version = ">= 2.26.0" }
        helm = { source = "hashicorp/helm", version = ">= 2.11.0" }
      }
    }
    provider "aws" {
      region = "${local.aws_region}"
      default_tags { tags = { Project = "${local.project}", Env = "${local.env}", Managed = "terragrunt" } }
    }
  EOF
}
