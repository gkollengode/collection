aws_region = "us-east-1"
name_prefix = "t3c-dev"
vpc_cidr = "10.40.0.0/16"
private_subnet_cidrs = ["10.40.1.0/24", "10.40.2.0/24", "10.40.3.0/24"]
public_subnet_cidrs  = ["10.40.101.0/24", "10.40.102.0/24", "10.40.103.0/24"]

# nodegroups to create in stage 02
nodegroups = {
  ng_general = {
    desired_size = 2
    min_size     = 2
    max_size     = 5
    instance_types = ["m6i.large"]
    capacity_type  = "ON_DEMAND"
  }
  ng_spot = {
    desired_size = 1
    min_size     = 0
    max_size     = 4
    instance_types = ["m6i.large","m5.large"]
    capacity_type  = "SPOT"
  }
}

# Splunk logging config used in stage 03
splunk_hec_url   = "https://http-inputs.example.splunkcloud.com/services/collector"
splunk_hec_token = "REDACTED_TOKEN"
splunk_index     = "eks-logs"
