bucket = "my-tofu-state-bucket-prod"
key    = "eks-blueprint/01_cluster/terraform.tfstate"
region = "us-east-1"
dynamodb_table = "my-tofu-locks-prod"
encrypt = true
