# EKS OpenTofu Blueprint (staged applies)

This blueprint creates an Amazon EKS control plane first, then adds managed node groups as incremental updates, and finally installs logging to Splunk.

## Stages

1. **01_cluster**: VPC, EKS control plane, IRSA. No node groups yet.
2. **02_nodegroups**: One or more managed node groups that attach to the cluster created in stage 01.
3. **03_addons_logging**: Optional logging to Splunk using fluent-bit Helm chart or Splunk OpenTelemetry Collector DaemonSet.

Each stage has its own state and can be applied independently. Stage 02 and 03 read outputs from stage 01 via `terraform_remote_state`.

## Prereqs

- OpenTofu 1.6+
- AWS credentials with permission to create VPC, EKS, IAM, and CloudWatch resources
- A bucket and DynamoDB table for remote state (optional but recommended)

## Fast start

```bash
# pick an environment
cd envs/dev

# init backend for 01_cluster then apply
cd ../../stages/01_cluster
tofu init -backend-config=../../envs/dev/backend.hcl
tofu apply -var-file=../../envs/dev/terraform.tfvars

# add or change node groups
cd ../02_nodegroups
tofu init -backend-config=../../envs/dev/backend.hcl
tofu apply -var-file=../../envs/dev/terraform.tfvars

# optional Splunk logging
cd ../03_addons_logging
tofu init -backend-config=../../envs/dev/backend.hcl
tofu apply -var-file=../../envs/dev/terraform.tfvars
```

## Remote state layout

Each stage manages its own state. Stage 02 and 03 reference the state outputs of 01 via `data.terraform_remote_state.cluster`.

Update `envs/*/backend.hcl` and `envs/*/terraform.tfvars` to match your accounts and preferences.

## New stage 03_addons_core

Installs official EKS addons using `aws_eks_addon` resources: vpc-cni, kube-proxy, coredns, and optional aws-ebs-csi-driver. Apply this after stage 01 and before or after stage 02.

Example:
```bash
cd stages/03_addons_core
tofu init -backend-config=../../envs/dev/backend.hcl
tofu apply -var-file=../../envs/dev/terraform.tfvars
```

## Optional stage 05_gitops_flux

Installs Flux via Helm and optionally deploys a sample Application. This is a simple onramp to GitOps for app delivery. Enable `create_example_app = true` to see it in action.

## GitLab CI

A `.gitlab-ci.yml` is included. Run jobs with variables to target a stage and environment:

- `STAGE=01_cluster ENV=dev` for control plane
- `STAGE=02_nodegroups ENV=dev` for node groups
- `STAGE=03_addons_core ENV=dev` for core addons
- `STAGE=03_addons_logging ENV=dev` for Splunk logging
- `STAGE=05_gitops_flux ENV=dev` for Flux

Set required variables in GitLab CI/CD settings:
- `TOFU_BUCKET`, `TOFU_DDB_TABLE`, `AWS_DEFAULT_REGION`
- Optionally `SPLUNK_HEC_URL`, `SPLUNK_HEC_TOKEN`, `SPLUNK_INDEX` for logging stage


### Flux GitOps (stage 05_gitops_flux)

Installs Flux controllers via Helm and, by default, creates GitRepository and Kustomization objects to sync a Git repo. Configure in `envs/*/terraform.tfvars` or pass as `-var` flags:

```hcl
git_url   = "https://github.com/your-org/your-gitops-repo"
git_branch = "main"
git_path   = "clusters/dev"
```

Apply:
```bash
cd stages/05_gitops_flux
tofu init -backend-config=../../envs/dev/backend.hcl
tofu apply -var-file=../../envs/dev/terraform.tfvars
```
