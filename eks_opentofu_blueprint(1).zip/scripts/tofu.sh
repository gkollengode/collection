#!/usr/bin/env bash
set -euo pipefail

STAGE="${1:-01_cluster}"
ENV="${2:-dev}"

pushd "stages/${STAGE}" >/dev/null

tofu init -backend-config="bucket=${TOFU_BUCKET}"   -backend-config="key=eks-blueprint/${STAGE}/terraform.tfstate"   -backend-config="region=${AWS_DEFAULT_REGION}"   -backend-config="dynamodb_table=${TOFU_DDB_TABLE}"

tofu apply -auto-approve -var-file="../../envs/${ENV}/terraform.tfvars"

popd >/dev/null
