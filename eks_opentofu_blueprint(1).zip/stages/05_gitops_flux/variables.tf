variable "aws_region" { type = string }
variable "state_bucket" { type = string, default = "my-tofu-state-bucket" }
variable "state_region" { type = string, default = "us-east-1" }
variable "state_key_cluster" { type = string, default = "eks-blueprint/01_cluster/terraform.tfstate" }

variable "flux_chart_version" {
  type        = string
  description = "Flux Helm chart version (flux2). Leave empty for latest."
  default     = ""
}

variable "create_gitops_objects" {
  type        = bool
  description = "Create GitRepository and Kustomization CRs to sync a repo"
  default     = true
}

variable "git_url" {
  type        = string
  description = "Git repository URL to sync (HTTPS)"
  default     = "https://github.com/example/eks-gitops"
}

variable "git_branch" {
  type        = string
  description = "Branch to sync"
  default     = "main"
}

variable "git_path" {
  type        = string
  description = "Path within the repo to apply (directory with kustomization.yaml or plain manifests)"
  default     = "clusters/dev"
}

variable "namespace" {
  type        = string
  description = "Namespace to install Flux"
  default     = "flux-system"
}
