# Install Flux controllers via Helm chart
resource "kubernetes_namespace" "flux" {
  metadata { name = var.namespace }
}

resource "helm_release" "flux" {
  name       = "flux2"
  repository = "https://fluxcd-community.github.io/helm-charts"
  chart      = "flux2"
  namespace  = kubernetes_namespace.flux.metadata[0].name

  # Set version only when provided
  version    = var.flux_chart_version != "" ? var.flux_chart_version : null

  values = [yamlencode({
    installCRDs = true
    components = {
      notificationController = { create = true }
      helmController         = { create = true }
      kustomizeController    = { create = true }
      sourceController       = { create = true }
      imageAutomationController = { create = false }
      imageReflectorController  = { create = false }
    }
  })]
}

# Optionally create GitRepository and Kustomization CRDs for GitOps sync
resource "kubernetes_manifest" "git_repo" {
  count = var.create_gitops_objects ? 1 : 0
  manifest = {
    apiVersion = "source.toolkit.fluxcd.io/v1"
    kind = "GitRepository"
    metadata = {
      name = "cluster-config"
      namespace = var.namespace
    }
    spec = {
      url = var.git_url
      interval = "1m0s"
      ref = { branch = var.git_branch }
      ignore = |
        # exclude anything you don't want Flux to apply
        .git/*
    }
  }
  depends_on = [helm_release.flux]
}

resource "kubernetes_manifest" "kustomization" {
  count = var.create_gitops_objects ? 1 : 0
  manifest = {
    apiVersion = "kustomize.toolkit.fluxcd.io/v1"
    kind = "Kustomization"
    metadata = {
      name = "cluster-sync"
      namespace = var.namespace
    }
    spec = {
      interval = "1m0s"
      path = var.git_path
      prune = true
      sourceRef = {
        kind = "GitRepository"
        name = "cluster-config"
      }
      wait = true
    }
  }
  depends_on = [kubernetes_manifest.git_repo]
}
