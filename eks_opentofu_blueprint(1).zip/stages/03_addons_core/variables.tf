variable "aws_region" {
  type        = string
  description = "AWS region"
}

variable "state_bucket" {
  type        = string
  description = "Remote state bucket for stage 01"
  default     = "my-tofu-state-bucket"
}

variable "state_region" {
  type        = string
  description = "Region of the state bucket"
  default     = "us-east-1"
}

variable "state_key_cluster" {
  type        = string
  description = "State key path for stage 01"
  default     = "eks-blueprint/01_cluster/terraform.tfstate"
}

variable "addon_versions" {
  description = "Optional map of addon versions"
  type = object({
    vpc_cni   = optional(string)
    kube_proxy = optional(string)
    coredns   = optional(string)
    ebs_csi   = optional(string)
  })
  default = {}
}

variable "enable_ebs_csi" {
  type        = bool
  description = "Install EBS CSI driver addon"
  default     = true
}
