locals {
  cluster_name = data.aws_eks_cluster.this.name
}

resource "aws_eks_addon" "vpc_cni" {
  cluster_name = local.cluster_name
  addon_name   = "vpc-cni"
  addon_version = try(var.addon_versions.vpc_cni, null)
  resolve_conflicts_on_update = "PRESERVE"
}

resource "aws_eks_addon" "kube_proxy" {
  cluster_name = local.cluster_name
  addon_name   = "kube-proxy"
  addon_version = try(var.addon_versions.kube_proxy, null)
  resolve_conflicts_on_update = "OVERWRITE"
}

resource "aws_eks_addon" "coredns" {
  cluster_name = local.cluster_name
  addon_name   = "coredns"
  addon_version = try(var.addon_versions.coredns, null)
  resolve_conflicts_on_update = "OVERWRITE"
}

resource "aws_eks_addon" "ebs_csi" {
  count = var.enable_ebs_csi ? 1 : 0
  cluster_name = local.cluster_name
  addon_name   = "aws-ebs-csi-driver"
  addon_version = try(var.addon_versions.ebs_csi, null)
  resolve_conflicts_on_update = "OVERWRITE"
}
