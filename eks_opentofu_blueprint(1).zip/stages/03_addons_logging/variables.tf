variable "aws_region" {
  type        = string
  description = "AWS region"
}

variable "state_bucket" {
  type        = string
  description = "Remote state bucket for stage 01"
  default     = "my-tofu-state-bucket"
}

variable "state_region" {
  type        = string
  description = "Region of the state bucket"
  default     = "us-east-1"
}

variable "state_key_cluster" {
  type        = string
  description = "State key path for stage 01"
  default     = "eks-blueprint/01_cluster/terraform.tfstate"
}

variable "splunk_hec_url" {
  type        = string
  description = "Splunk HEC URL"
}

variable "splunk_hec_token" {
  type        = string
  description = "Splunk HEC token"
  sensitive   = true
}

variable "splunk_index" {
  type        = string
  description = "Default index name"
  default     = "eks-logs"
}

variable "install_otel" {
  type        = bool
  description = "Install Splunk OpenTelemetry Collector instead of fluent-bit"
  default     = false
}
