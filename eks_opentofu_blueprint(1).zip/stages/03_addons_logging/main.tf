# namespace
resource "kubernetes_namespace" "observability" {
  metadata { name = "observability" }
}

# Option A: fluent-bit to Splunk HEC
resource "helm_release" "fluent_bit" {
  count = var.install_otel ? 0 : 1

  name       = "fluent-bit"
  repository = "https://fluent.github.io/helm-charts"
  chart      = "fluent-bit"
  namespace  = kubernetes_namespace.observability.metadata[0].name

  values = [yamlencode({
    serviceAccount = { create = true, name = "fluent-bit" }
    config = {
      outputs = f"""
[Output]
    Name  splunk
    Match *
    Host  ${var.splunk_hec_url}
    TLS   On
    Splunk_Token ${var.splunk_hec_token}
    Splunk_Send_Raw On
    Splunk_Index ${var.splunk_index}
"""
    }
    backend = { type = "forward" }
  })]
}

# Option B: Splunk OpenTelemetry Collector
resource "helm_release" "splunk_otel" {
  count = var.install_otel ? 1 : 0

  name       = "splunk-otel-collector"
  repository = "https://signalfx.github.io/splunk-otel-collector-chart"
  chart      = "splunk-otel-collector"
  namespace  = kubernetes_namespace.observability.metadata[0].name

  values = [yamlencode({
    splunkObservability = {
      accessToken = var.splunk_hec_token
      realm       = "us0"
    }
    clusterName = data.aws_eks_cluster.this.name
    environment = "prod"
    fluentd    = { enabled = false }
    logsCollection = {
      enabled = true
      splunk = {
        hec = {
          token = var.splunk_hec_token
          endpoint = var.splunk_hec_url
        }
        index = var.splunk_index
      }
    }
  })]
}
