# read stage 01 outputs
data "terraform_remote_state" "cluster" {
  backend = "s3"
  config = {
    bucket = var.state_bucket
    key    = var.state_key_cluster
    region = var.state_region
  }
}

locals {
  cluster_name = data.terraform_remote_state.cluster.outputs.cluster_name
  subnet_ids   = data.terraform_remote_state.cluster.outputs.private_subnet_ids
}

# IAM role for nodes
data "aws_iam_policy_document" "node_assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "node" {
  name               = "${var.name_prefix}-eks-node-role"
  assume_role_policy = data.aws_iam_policy_document.node_assume.json
}

resource "aws_iam_role_policy_attachment" "node_policies" {
  for_each = toset([
    "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy",
    "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy",
    "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly",
    "arn:aws:iam::aws:policy/CloudWatchAgentServerPolicy"
  ])
  role       = aws_iam_role.node.name
  policy_arn = each.value
}

# Create one aws_eks_node_group per entry
resource "aws_eks_node_group" "this" {
  for_each = var.nodegroups

  cluster_name    = local.cluster_name
  node_group_name = each.key
  node_role_arn   = aws_iam_role.node.arn
  subnet_ids      = local.subnet_ids

  scaling_config {
    desired_size = each.value.desired_size
    min_size     = each.value.min_size
    max_size     = each.value.max_size
  }

  capacity_type  = each.value.capacity_type
  instance_types = each.value.instance_types

  update_config {
    max_unavailable = 1
  }

  tags = {
    "Name" = "${var.name_prefix}-${each.key}"
  }
}

output "nodegroup_names" {
  value = [for k, v in aws_eks_node_group.this : v.node_group_name]
}
