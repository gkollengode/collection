variable "aws_region" {
  type        = string
  description = "AWS region"
}

variable "name_prefix" {
  type        = string
  description = "Name prefix used in stage 01"
}

variable "nodegroups" {
  description = "Map of node group settings"
  type = map(object({
    desired_size   = number
    min_size       = number
    max_size       = number
    instance_types = list(string)
    capacity_type  = string # ON_DEMAND or SPOT
  }))
  default = {}
}

variable "state_bucket" {
  type        = string
  description = "Remote state bucket for stage 01"
  default     = "my-tofu-state-bucket"
}

variable "state_region" {
  type        = string
  description = "Region of the state bucket"
  default     = "us-east-1"
}

variable "state_key_cluster" {
  type        = string
  description = "State key path for stage 01"
  default     = "eks-blueprint/01_cluster/terraform.tfstate"
}
