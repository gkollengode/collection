<div style="padding:14px;border-radius:14px;background:linear-gradient(135deg,#a855f7,#06b6d4);color:#0f052e;">
  <h1 style="margin:0;">Tool Status</h1>
  <p style="margin:0;">Coverage and health of the security toolchain</p>
</div>

| Tool | Purpose | Coverage | Last Run | Status |
|---|---|---|---|---|
| SAST | Static code analysis | 95% repos | 2025-09-01 | ✅ Healthy |
| DAST | Dynamic testing | 18 apps | 2025-09-09 | ⚠️ Intermittent |
| Dependency Scanning | SCA | 110 repos | 2025-09-12 | ✅ Healthy |
| Container Scanning | Image CVEs | 42 images | 2025-09-12 | ⛔ Needs attention |
| Secret Detection | Secrets in code | 100% repos | 2025-09-13 | ✅ Healthy |

**Action Items**
- Ensure new repos inherit security templates
- Add missing variables and tokens
- Review false positives weekly
