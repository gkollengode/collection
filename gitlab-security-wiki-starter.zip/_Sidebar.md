<div style="padding:10px;border-radius:12px;background:linear-gradient(135deg,#111827,#1f2937,#0ea5e9);color:white;">
  <h2 style="margin:0;">Security Wiki</h2>
  <p style="margin:0;">Quick links</p>
</div>

- [[Home]]
- [[Vulnerability Dashboard]]
- [[Tool Status]]
- [[Risk Register]]
- [[SLA Tracking]]
- [[SBOM & Supply Chain]]
- [[Findings Template]]
- [[Policies & Standards]]
- [[Data Dictionary]]
- [[How to Contribute]]
