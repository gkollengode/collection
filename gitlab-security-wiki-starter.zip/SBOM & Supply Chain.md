<div style="padding:14px;border-radius:14px;background:linear-gradient(135deg,#0ea5e9,#a855f7);color:#0b0b1f;">
  <h1 style="margin:0;">SBOM and Supply Chain</h1>
</div>

- Store SBOMs in `assets/sbom/` in SPDX or CycloneDX format
- Track attestations and provenance

| Component | Version | Source | License | Critical CVEs | SBOM |
|---|---|---|---|---|---|
| base-image | 1.2.3 | registry.example.com/base | Apache-2.0 | 1 | assets/sbom/base-image.spdx.json |
