<div style="padding:14px;border-radius:14px;background:linear-gradient(135deg,#ef4444,#f59e0b);color:#1c0800;">
  <h1 style="margin:0;">Risk Register</h1>
</div>

| ID | Risk | Impact | Likelihood | Owner | Mitigation | Status |
|---|---|---|---|---|---|---|
| R-001 | Stale base image CVEs | High | Medium | Platform | Quarterly base image updates | Open |
| R-002 | Secrets exposure | High | Medium | SecOps | Pre-commit hooks and scanners | Mitigating |
| R-003 | 3rd party package risk | Medium | Medium | App Teams | SBOM attestations | Open |
