<div style="padding:14px;border-radius:14px;background:linear-gradient(135deg,#06b6d4,#22c55e);color:#012014;">
  <h1 style="margin:0;">SLA Tracking</h1>
</div>

> Define and track time to triage and time to remediate by severity

| Severity | Triage SLA | Fix SLA | Current Breaches | Notes |
|---|---|---|---|---|
| Critical | 24h | 7d | 0 |  |
| High | 3d | 14d | 2 |  |
| Medium | 7d | 30d | 7 |  |
| Low | 14d | 90d | 0 |  |

**Query Hints**
- Use GitLab Security Dashboard filters or your aggregator to compute open age buckets
