<div style="padding:14px;border-radius:14px;background:linear-gradient(135deg,#f59e0b,#ef4444);color:#1c0800;">
  <h1 style="margin:0;">Findings Template</h1>
</div>

**ID**: SEC-YYYY-NNNN  
**Title**:  
**Severity**: Critical High Medium Low Info  
**CVSS**:  
**Category**: SAST DAST SCA Container Secrets Other  
**Affected Assets**:  
**Description**:  
**Steps to Reproduce**:  
**Impact**:  
**Recommendation**:  
**Owner**:  
**Created**:  
**Target Fix Date**:  
**Status**: Open In Progress Mitigated Accepted False Positive

> Paste screenshots in `assets/findings/` and link them here.
