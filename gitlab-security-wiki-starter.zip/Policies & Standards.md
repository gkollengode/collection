<div style="padding:14px;border-radius:14px;background:linear-gradient(135deg,#111827,#0ea5e9);color:#f3f4f6;">
  <h1 style="margin:0;">Policies and Standards</h1>
</div>

- Vulnerability Management Policy
- Exceptions and Risk Acceptance
- Secure Coding Guidelines
- CI templates and enforcement

```yaml
# .gitlab-ci.yml snippet for security templates
include:
  - project: <group>/security-templates
    file: [.security/sast.yml, .security/dep_scan.yml, .security/container_scan.yml]
```
