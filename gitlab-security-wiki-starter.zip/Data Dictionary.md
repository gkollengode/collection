<div style="padding:14px;border-radius:14px;background:linear-gradient(135deg,#06b6d4,#f59e0b);color:#0b0b0b;">
  <h1 style="margin:0;">Data Dictionary</h1>
</div>

| Field | Meaning | Example |
|---|---|---|
| Severity | Finding priority | High |
| Age | Days since created | 23 |
| SLA Breach | Whether fix due date passed | Yes |
