<div style="padding:14px;border-radius:14px;background:linear-gradient(135deg,#22c55e,#84cc16);color:#0c1a0a;">
  <h1 style="margin:0;">How to Contribute</h1>
</div>

1. Clone the wiki repository
2. Edit markdown locally or in the GitLab web UI
3. Keep exports in `assets/exports/` and images in `assets/img/`

**Structure**
```
/Home.md
/_Sidebar.md
/Vulnerability Dashboard.md
/Tool Status.md
/Risk Register.md
/SLA Tracking.md
/SBOM & Supply Chain.md
/Findings Template.md
/Policies & Standards.md
/Data Dictionary.md
/assets/
  exports/
  findings/
  img/
  sbom/
```
