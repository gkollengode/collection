<div style="padding:18px;border-radius:16px;background:linear-gradient(135deg,#0ea5e9,#22c55e);color:#0b1020;">
  <h1 style="margin:0;">Security Reporting Hub</h1>
  <p style="margin:0;">Executive overview and live status</p>
</div>

> Replace the placeholders with your project path to enable live GitLab badges.

### Pipelines and Coverage
[![pipeline status](https://gitlab.example.com/<group>/<project>/badges/main/pipeline.svg)](https://gitlab.example.com/<group>/<project>/-/pipelines)
[![coverage report](https://gitlab.example.com/<group>/<project>/badges/main/coverage.svg)](https://gitlab.example.com/<group>/<project>/-/graphs/master/charts)

### AppSec Scans
[![SAST](https://img.shields.io/badge/SAST-status-blue)](#)
[![DAST](https://img.shields.io/badge/DAST-status-blue)](#)
[![Dependency Scanning](https://img.shields.io/badge/Dependency%20Scan-status-blue)](#)
[![Container Scan](https://img.shields.io/badge/Container%20Scan-status-blue)](#)
[![Secret Detection](https://img.shields.io/badge/Secrets-status-blue)](#)

### This Week at a Glance
```mermaid
pie title Open Findings by Severity
  "Critical" : 3
  "High" : 12
  "Medium" : 26
  "Low" : 18
  "Info" : 5
```

### Top Risks
<table>
  <tr><th>Risk</th><th>Impact</th><th>Likelihood</th><th>Owner</th><th>Status</th></tr>
  <tr><td>Exposed keys</td><td style="background:#fecaca;">High</td><td style="background:#fde68a;">Medium</td><td>SecOps</td><td>Mitigating</td></tr>
  <tr><td>Critical CVEs in base image</td><td style="background:#fecaca;">High</td><td style="background:#fed7aa;">Elevated</td><td>Platform</td><td>In progress</td></tr>
</table>

### Key Links
- [[Vulnerability Dashboard]]
- [[SLA Tracking]]
- [[Tool Status]]
- [[Risk Register]]
